package com.cg.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.entities.Account;

import com.cg.service.AccountService;
import com.cg.service.Transaction;

@CrossOrigin("http://localhost:4200")
@RestController
@RequestMapping("/wallet")
public class WalletController {

	@Autowired
	AccountService service;

	@Autowired(required = false)
	Transaction transact;

	@PostMapping(value = "/create", consumes = { "application/json" })
	public String create(@RequestBody Account ac) {
		service.addAccount(ac);
		return "Successfully added";
	}

	@GetMapping(value = "/view-all")
	public List<Account> findAll() {
		return service.getAllAccounts();
	}

	@GetMapping(value = "/view/{mobile}")
	public Account findByMobile(@PathVariable long mobile) {
		return service.findAccount(mobile);
	}

	@DeleteMapping(value = "/delete/{mobile}")
	public String delete(@PathVariable long mobile) {
		service.deleteAccount(mobile);
		return "country deleted";
	}

	@PutMapping(value = "/update/{mobile}")
	public boolean updateAccount(@RequestBody Account ac, @PathVariable("mobile") long mobile) {

		service.updateAccount(ac);
		return true;
	}

	@PutMapping(value = "/services/deposite/{mobile}/{amount}")
	public double depositeMoney(@PathVariable("mobile") long mobile, @PathVariable("amount") double amount) {
		Account ac = service.findAccount(mobile);
		return transact.deposite(ac, amount);
	}

	@PutMapping(value="/services/withdraw/{mobile}/{amount}")
	public double withdrawMoney(@PathVariable("mobile") long mobile, @PathVariable("amount") double amount) {
		Account ac=service.findAccount(mobile);
		return transact.withdraw(ac, amount);
	}
	
	@PutMapping(value="/services/transfer/{fromMob}/{toMob}/{amount}")
	public boolean transferMoney(@PathVariable("fromMob") long fromMob,@PathVariable("toMob") long toMob, @PathVariable("amount") double amount) {
		Account from=service.findAccount(fromMob);
		Account to=service.findAccount(toMob);
		return transact.transferMoney(from, to, amount);
		
	}
	
}

package com.cg.DAOs;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.entities.Account;

public interface AccountDAO extends JpaRepository<Account, Long> {

}

package com.cg.service;

import org.springframework.stereotype.Repository;

import org.springframework.transaction.annotation.Transactional;

import com.cg.entities.Account;

@Repository
@Transactional
public interface Transaction extends AccountOperation {
	public double withdraw(Account ob, double amount);

	public boolean transferMoney(Account from, Account to, double amount);

	public double deposite(Account ob, double amount);
}

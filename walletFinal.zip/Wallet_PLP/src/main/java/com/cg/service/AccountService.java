package com.cg.service;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.entities.Account;
@Service
@Transactional
public interface AccountService {

	public void addAccount(Account ob);// success
	
	public List<Account> getAllAccounts();
	
	public Account findAccount(Long mobileno);// success

	public void deleteAccount(Long mobileno);// success

	public boolean updateAccount(Account ob);
	
}

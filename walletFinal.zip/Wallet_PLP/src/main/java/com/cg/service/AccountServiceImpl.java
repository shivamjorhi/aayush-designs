package com.cg.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.cg.DAOs.AccountDAO;
import com.cg.entities.Account;
@Service
@Transactional
public class AccountServiceImpl implements AccountService,Transaction {

	@Autowired
	AccountDAO dao;
	
	@Transactional(propagation=Propagation.REQUIRED)
	public void addAccount(Account ob) {
		dao.save(ob);
	}
	
	public List<Account> getAllAccounts() {
		return dao.findAll();
	}

	public Account findAccount(Long mobileno) {
		Optional<Account> ac=dao.findById(mobileno);
		return ac.get();
	}
	
	public void deleteAccount(Long mobileno) {
		dao.deleteById(mobileno);
	}
	
	public boolean updateAccount(Account ob) {
		dao.save(ob);
		return true;
	}
	
	@Transactional(propagation=Propagation.REQUIRED)
	public double deposite(Account ob, double amount) {
		
		double bal = ob.getBalance();
		System.out.println(bal);
		double upd_bal = bal + amount;
		ob.setBalance(upd_bal);
		
		dao.save(ob);
		
		return upd_bal;
	}
	
	public double withdraw(Account ob, double amount) {
		double new_balance = ob.getBalance() - amount;
		if (new_balance < 100.00) {
			new_balance = ob.getBalance();

			// throw new RuntimeException("Insufficient Fund. Can not proceed further");
			// throw new InsufficientFundException("Insufficient Fund. Can not proceed
			// further", new_balance);
		}
		ob.setBalance(new_balance);

		dao.save(ob);
		return new_balance;
	}


	public boolean transferMoney(Account from, Account to, double amount) {
		// TODO Auto-generated method stub
		double bal = from.getBalance() - amount;
		double bal1 = to.getBalance() + amount;

		from.setBalance(bal);
		to.setBalance(bal1);

		dao.save(from);
		dao.save(to);
		
		return true;
	}
}

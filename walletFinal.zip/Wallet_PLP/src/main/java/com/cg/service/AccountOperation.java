package com.cg.service;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.entities.*;

@Transactional
public interface AccountOperation {

	public void addAccount(Account ob);

	public void deleteAccount(Long mobileno);

	public Account findAccount(Long mobileno);

	public List<Account> getAllAccounts();

}
